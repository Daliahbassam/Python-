import json
import re

contacts = []

def load_contacts():
    try:
        with open('contacts.json', 'r') as file:
            contacts_data = json.load(file)
            
        for contact in contacts_data:
            # Format the phone number
            contact['phone'] = format_phone_number(contact['phone'].replace('+966 ', ''))
            
        return contacts_data
    except FileNotFoundError:
        return []

def save_contacts():
    with open('contacts.json', 'w') as file:
        json.dump(contacts, file)

def display_menu():
    print("\n-- Contact Management System --")
    print("Please select an option:")
    print("1. Add Contact")
    print("2. View Contacts")
    print("3. Update Contact")
    print("4. Delete Contact")
    print("5. Exit")

def add_contact():
    while True:
        name = input("Enter the contact's name: ").strip()
        if not name:
            print("Error: Name cannot be empty. Please try again.")
            continue

        phone = input("Enter the contact's phone number: ").strip()
        if not validate_phone_number(phone):
            print("Error: Invalid phone number. Please enter a 9-digit number.")
            continue

        # Format the phone number
        formatted_phone = format_phone_number(phone)

        email = input("Enter the contact's email: ").strip()
        if not validate_email(email):
            print("Error: Invalid email address. Please enter a valid email.")
            continue

        contacts.append({"name": name, "phone": formatted_phone, "email": email})
        save_contacts()
        print(f"Contact added successfully! The phone number will be saved as: {formatted_phone}")
        break

def format_phone_number(phone):
    # Remove any leading zeros
    phone = phone.lstrip('0')
    
    # Format the phone number
    return f"+966 {phone[:2]} {phone[2:5]} {phone[5:]}"

def validate_phone_number(phone):
    # Regular expression to validate 9-digit phone number
    pattern = r'^\d{9}$'
    return bool(re.match(pattern, phone))

def validate_email(email):
    # Regular expression to validate email format
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return bool(re.match(pattern, email))

def view_contacts():
    if not contacts:
        print("No contacts found.")
    else:
        for index, contact in enumerate(contacts):
            print(f"{index + 1}. {contact['name']} - {contact['phone']} - {contact['email']}")
            # This function prints current list of contacts  it first checks and it adds to index 1 because it starts with zero  
            

def update_contact():
    view_contacts()
    if not contacts:
        return
    index = int(input("Enter the number of the contact to update: ")) - 1
    if 0 <= index < len(contacts):
        name = input("Enter new name: ")
        if name.strip():
            contacts[index]['name'] = name
        phone = input("Enter new phone number: ")
        if phone.strip():
            contacts[index]['phone'] = phone
        email = input("Enter new email: ")
        if email.strip():
            contacts[index]['email'] = email
        save_contacts()
        print("Contact updated successfully.")
    else:
        print("Invalid contact number")

def delete_contact():
    view_contacts()
    if not contacts:
        return
    index = int(input("Enter the number of the contact to delete: ")) - 1
    if 0 <= index < len(contacts):
        deleted_contact = contacts.pop(index)
        save_contacts()
        print(f"Deleted contact: {deleted_contact['name']} - {deleted_contact['phone']} - {deleted_contact['email']}")
    else:
        print("Invalid contact number")

def main():
    global contacts
    contacts = load_contacts()
    while True:
        display_menu()
        choice = input("Enter choice (1/2/3/4/5): ")
        if choice == '1':
            add_contact()
        elif choice == '2':
            view_contacts()
        elif choice == '3':
            update_contact()
        elif choice == '4':
            delete_contact()
        elif choice == '5':
            break
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()
# Is used to ensure that the main() function is only executed when the script is run directly, and not when the script is imported as a module.
