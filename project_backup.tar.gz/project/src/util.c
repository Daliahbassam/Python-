This is the util.c file
