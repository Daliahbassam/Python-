This is the main.c file
